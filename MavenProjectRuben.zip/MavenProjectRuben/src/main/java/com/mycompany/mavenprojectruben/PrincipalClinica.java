package com.mycompany.mavenprojectruben;

import clases.Sesion;
import clases.TipoPerfil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Pattern;

/**
 *
 * @author Ruben
 */
public class PrincipalClinica {

    static Scanner sc = new Scanner(System.in);
    // Declaro el objeto sesion para que guarde los datos
    static Sesion sesion = new Sesion();

    // ===== CU2: constantes =====
    private static final Path RUTA_CREDENCIALES = Path.of("credenciales.txt");
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    private static final Pattern TELEFONO = Pattern.compile("^\\d{9}$");
    private static final Pattern NIF_NIE = Pattern.compile("^([XYZ]\\d{7}|\\d{8})[A-Z]$");
    private static final String LETRAS_NIF = "TRWAGMYFPDXBNJZSQVHLCKE";
    private static final String[] ESPECIALIDADES = {
        "Odontología", "Fisioterapia", "Ginecología", "Cirugía plástica",
        "Digestivo", "Cirugía pediátrica", "Radiología", "Geriatría"
    };

    // Lee un entero sin que el programa se cierre si se escribe otra cosa
    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.println(mensaje);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Debes introducir un número.");
            }
        }
    }

    private static String[] login() {
        System.out.println("Nombre de usuario");
        String usuario = sc.nextLine();
        System.out.println("Contraseña");
        String password = sc.nextLine();

        if (usuario.isBlank() || password.isBlank()) {
            System.out.println("El campo usuario y contraseña no pueden estar vacios");
            return null;
        }
        return new String[]{usuario, password};
    }

    private static Properties cargarPropiedades() {
        Properties propiedades = new Properties();

        try (InputStream entrada = PrincipalClinica.class
                .getClassLoader()
                .getResourceAsStream("application.properties")) {

            if (entrada == null) {
                System.out.println("No se encuentra application.properties");
                return null;
            }

            propiedades.load(entrada);

        } catch (IOException e) {
            System.out.println("Error al leer las propiedades");
            return null;
        }

        return propiedades;
    }

    // Menú de un usuario ya autenticado. Termina cuando cierra sesión.
    private static void mostrarMenuPerfil() {
        int opcion;

        do {
            // Mostrar las opciones según el perfil
            System.out.println("--- MENÚ " + sesion.getTipoPerfil() + " ---");

            switch (sesion.getTipoPerfil()) {
                case SECRETARIADO:
                    System.out.println("1.- Gestionar empleados");
                    System.out.println("2.- Cerrar sesión");
                    break;

                case ENFERMERIA:
                    System.out.println("1.- Gestionar alergias y medicamentos");
                    System.out.println("2.- Cerrar sesión");
                    break;

                case ADMINISTRADOR:
                    System.out.println("1.- Gestionar empleados");
                    System.out.println("2.- Gestionar alergias y medicamentos");
                    System.out.println("3.- Cerrar sesión");
                    break;

                default:
                    break;
            }

            opcion = leerEntero("Elige una opción:");

            // Ejecutar la opción seleccionada
            switch (sesion.getTipoPerfil()) {

                case SECRETARIADO:
                    switch (opcion) {
                        case 1:
                            gestionarEmpleados();   // CU2
                            break;
                        case 2:
                            cerrarSesion();
                            break;
                        default:
                            System.out.println("Opción incorrecta.");
                    }
                    break;

                case ENFERMERIA:
                    switch (opcion) {
                        case 1:
                            System.out.println("Aquí irá la gestión de alergias y medicamentos.");
                            break;
                        case 2:
                            cerrarSesion();
                            break;
                        default:
                            System.out.println("Opción incorrecta.");
                    }
                    break;

                case ADMINISTRADOR:
                    switch (opcion) {
                        case 1:
                            gestionarEmpleados();   // CU2
                            break;
                        case 2:
                            System.out.println("Aquí irá la gestión de alergias y medicamentos.");
                            break;
                        case 3:
                            cerrarSesion();
                            break;
                        default:
                            System.out.println("Opción incorrecta.");
                    }
                    break;

                default:
                    break;
            }

        } while (sesion.isIniciada());
    }

    private static void cerrarSesion() {
        if (sesion.isIniciada()) {
            sesion.setUsuario(null);
            sesion.setNombre(null);
            sesion.setTipoPerfil(TipoPerfil.INVITADO);
            sesion.setIniciada(false);
            System.out.println("Sesion cerrada correctamente");
            System.out.println("Pasa a usuario invitado");
        }
    }

    // ===================== CU2: GESTIONAR PERSONAL =====================

    // Submenú de gestión de empleados (Secretariado y Administrador)
    private static void gestionarEmpleados() {
        int opcion;
        do {
            System.out.println("--- GESTIÓN DE EMPLEADOS ---");
            System.out.println("1.- Dar de alta un empleado");
            System.out.println("0.- Volver");
            opcion = leerEntero("Elige una opción:");

            switch (opcion) {
                case 1:
                    altaEmpleado();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción incorrecta.");
            }
        } while (opcion != 0);
    }

    // Lee un texto no vacío y sin el carácter '|' (que es el separador del fichero)
    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.println(mensaje);
            String valor = sc.nextLine().trim();
            if (valor.isEmpty()) {
                System.out.println("El campo no puede estar vacío.");
            } else if (valor.contains("|")) {
                System.out.println("El carácter '|' no está permitido.");
            } else {
                return valor;
            }
        }
    }

    // Lee un texto que debe cumplir un patrón
    private static String leerConPatron(String mensaje, Pattern patron, String error) {
        while (true) {
            String valor = leerTexto(mensaje);
            if (patron.matcher(valor).matches()) {
                return valor;
            }
            System.out.println(error);
        }
    }

    private static boolean nifNieValido(String valor) {
        if (!NIF_NIE.matcher(valor).matches()) {
            return false;
        }
        String numero = valor.substring(0, valor.length() - 1);
        char letra = valor.charAt(valor.length() - 1);
        // En el NIE la letra inicial se sustituye por 0, 1 o 2
        numero = numero.replaceFirst("^X", "0").replaceFirst("^Y", "1").replaceFirst("^Z", "2");
        return LETRAS_NIF.charAt(Integer.parseInt(numero) % 23) == letra;
    }

    private static String leerNifNie() {
        while (true) {
            String valor = leerTexto("NIF/NIE (ej: 12345678Z o X1234567L):").toUpperCase();
            if (nifNieValido(valor)) {
                return valor;
            }
            System.out.println("NIF/NIE no válido (formato o letra incorrectos).");
        }
    }

    private static boolean confirmar(String mensaje) {
        while (true) {
            System.out.println(mensaje + " (S/N)");
            String r = sc.nextLine().trim().toUpperCase();
            if (r.equals("S")) {
                return true;
            }
            if (r.equals("N")) {
                return false;
            }
            System.out.println("Responde S o N.");
        }
    }

    // Comprueba si el usuario ya existe en credenciales.txt o es el del administrador
    private static boolean usuarioExiste(String usuario) throws IOException {
        Properties propiedades = cargarPropiedades();
        if (propiedades != null && usuario.equals(propiedades.getProperty("admin.usuario"))) {
            return true;
        }
        for (String linea : Files.readAllLines(RUTA_CREDENCIALES)) {
            String[] datos = linea.split("\\|", -1);
            if (datos.length >= 1 && datos[0].equals(usuario)) {
                return true;
            }
        }
        return false;
    }

    private static void altaEmpleado() {
        System.out.println("--- ALTA DE EMPLEADO ---");

        // Tipo de empleado
        int tipo;
        do {
            System.out.println("Tipo de empleado:");
            System.out.println("1.- Secretariado");
            System.out.println("2.- Enfermería");
            System.out.println("3.- Cirujano/a");
            tipo = leerEntero("Elige el tipo:");
            if (tipo < 1 || tipo > 3) {
                System.out.println("Opción incorrecta.");
            }
        } while (tipo < 1 || tipo > 3);

        // Datos personales comunes
        String nombre = leerTexto("Nombre:");
        String apellidos = leerTexto("Apellidos:");
        String telefono = leerConPatron("Teléfono (9 dígitos):", TELEFONO,
                "El teléfono debe tener 9 dígitos.");
        String email = leerConPatron("Email:", EMAIL, "El email no tiene un formato válido.");
        String nif = leerNifNie();
        String direccion = leerTexto("Dirección:");

        // Datos propios del puesto
        String perfil;
        String datoPuesto;

        switch (tipo) {
            case 1: {
                perfil = "secretariado";
                int anios;
                do {
                    anios = leerEntero("Años de experiencia en la clínica:");
                    if (anios < 0 || anios > 60) {
                        System.out.println("Los años deben estar entre 0 y 60.");
                    }
                } while (anios < 0 || anios > 60);
                datoPuesto = "Años de experiencia: " + anios;
                break;
            }
            case 2: {
                perfil = "enfermeria";
                String categoria = leerConPatron("Categoría (A, B o C):", Pattern.compile("^[ABCabc]$"),
                        "La categoría debe ser A, B o C.").toUpperCase();
                datoPuesto = "Categoría: " + categoria;
                break;
            }
            default: {
                perfil = "cirujano";
                Set<Integer> elegidas = new LinkedHashSet<>();
                while (elegidas.isEmpty()) {
                    System.out.println("Especialidades disponibles:");
                    for (int i = 0; i < ESPECIALIDADES.length; i++) {
                        System.out.println((i + 1) + ".- " + ESPECIALIDADES[i]);
                    }
                    System.out.println("Introduce los números separados por comas (ej: 1,3):");
                    String[] partes = sc.nextLine().split(",");
                    boolean correcto = true;
                    Set<Integer> temporal = new LinkedHashSet<>();
                    for (String parte : partes) {
                        try {
                            int n = Integer.parseInt(parte.trim());
                            if (n < 1 || n > ESPECIALIDADES.length || !temporal.add(n)) {
                                correcto = false;
                            }
                        } catch (NumberFormatException e) {
                            correcto = false;
                        }
                    }
                    if (correcto && !temporal.isEmpty()) {
                        elegidas = temporal;
                    } else {
                        System.out.println("Selección no válida: usa números del 1 al "
                                + ESPECIALIDADES.length + " sin repetir.");
                    }
                }
                List<String> nombres = new ArrayList<>();
                for (int n : elegidas) {
                    nombres.add(ESPECIALIDADES[n - 1]);
                }
                datoPuesto = "Especialidades: " + String.join(", ", nombres);
                break;
            }
        }

        // Credenciales: si algo falla se informa de las causas y se paraliza el registro
        System.out.println("Nombre de usuario:");
        String usuario = sc.nextLine();
        System.out.println("Contraseña:");
        String password = sc.nextLine();

        List<String> errores = new ArrayList<>();
        if (usuario.isEmpty()) {
            errores.add("El nombre de usuario no puede estar vacío.");
        }
        if (password.isEmpty()) {
            errores.add("La contraseña no puede estar vacía.");
        }
        if (usuario.matches(".*\\s.*")) {
            errores.add("El nombre de usuario no puede contener espacios en blanco.");
        }
        if (password.matches(".*\\s.*")) {
            errores.add("La contraseña no puede contener espacios en blanco.");
        }
        if (usuario.contains("|") || password.contains("|")) {
            errores.add("El carácter '|' no está permitido en usuario ni contraseña.");
        }
        if (errores.isEmpty()) {
            try {
                if (usuarioExiste(usuario)) {
                    errores.add("El nombre de usuario '" + usuario + "' ya existe en el sistema.");
                }
            } catch (IOException e) {
                System.out.println("Error al leer credenciales.txt. Registro cancelado.");
                return;
            }
        }
        if (!errores.isEmpty()) {
            System.out.println("No se puede registrar al empleado por los siguientes motivos:");
            for (String error : errores) {
                System.out.println(" - " + error);
            }
            return;
        }

        // Resumen y confirmación
        String nombreCompleto = nombre + " " + apellidos;
        System.out.println("--- RESUMEN DEL NUEVO EMPLEADO ---");
        System.out.println("Nombre:     " + nombreCompleto);
        System.out.println("Teléfono:   " + telefono);
        System.out.println("Email:      " + email);
        System.out.println("NIF/NIE:    " + nif);
        System.out.println("Dirección:  " + direccion);
        System.out.println("Perfil:     " + perfil);
        System.out.println(datoPuesto);
        System.out.println("Usuario:    " + usuario);

        if (!confirmar("¿Confirmas el alta del empleado?")) {
            System.out.println("Alta cancelada.");
            return;
        }

        // Solo se persisten los datos que forman parte del fichero
        String linea = usuario + "|" + password + "|" + nombreCompleto + "|" + perfil;
        try {
            String contenido = Files.readString(RUTA_CREDENCIALES);
            // Si la última línea no acaba en salto de línea, se añade para no pegar registros
            String prefijo = (!contenido.isEmpty() && !contenido.endsWith("\n"))
                    ? System.lineSeparator() : "";
            Files.writeString(RUTA_CREDENCIALES, prefijo + linea + System.lineSeparator(),
                    StandardOpenOption.APPEND);
            System.out.println("Empleado registrado correctamente.");
        } catch (IOException e) {
            System.out.println("No se ha podido escribir en credenciales.txt.");
        }
    }

    public static void main(String[] args) {

        Path ruta = Path.of("credenciales.txt");

        // Si el fichero no existe se crea vacío para que no falle el login ni el CU2
        try {
            if (!Files.exists(ruta)) {
                Files.createFile(ruta);
            }
        } catch (IOException e) {
            System.out.println("No se ha podido crear credenciales.txt");
        }

        int opcion;
        boolean encontrado;

        do {
            // Menú del usuario invitado (el menú del resto de perfiles está en mostrarMenuPerfil)
            System.out.println("--- MENÚ PRINCIPAL ---");
            System.out.println("1.-Login");
            System.out.println("0.-Salir");
            opcion = leerEntero("Elige una opción:");

            switch (opcion) {
                case 1: {
                    if (sesion.isIniciada()) {
                        System.out.println("Ya hay una sesion iniciada. Cierra sesión antes de volver a entrar");
                        break;
                    }
                    String[] credenciales = login();
                    if (credenciales == null) {
                        break;
                    }
                    String usuarioIntroducido = credenciales[0];
                    String passwordIntroducida = credenciales[1];
                    encontrado = false;
                    Properties propiedades = cargarPropiedades();

                    if (propiedades != null) {
                        String usuarioAdmin = propiedades.getProperty("admin.usuario");
                        String passwordAdmin = propiedades.getProperty("admin.password");

                        if (usuarioIntroducido.equals(usuarioAdmin)
                                && passwordIntroducida.equals(passwordAdmin)) {

                            sesion.setUsuario(usuarioAdmin);
                            sesion.setNombre("Administrador General");
                            sesion.setTipoPerfil(TipoPerfil.ADMINISTRADOR);
                            sesion.setIniciada(true);

                            encontrado = true;
                            System.out.println("Bienvenido: Administrador General");
                        }
                    }
                    if (!encontrado) {

                        try (BufferedReader br = Files.newBufferedReader(ruta)) {
                            String linea;

                            while ((linea = br.readLine()) != null) {
                                String[] datos = linea.split("\\|", -1);

                                if (datos.length == 4) {
                                    String usuarioArchivo = datos[0];
                                    String passwordArchivo = datos[1];
                                    String nombre = datos[2];
                                    String perfilTexto = datos[3];

                                    TipoPerfil perfil;
                                    try {
                                        perfil = TipoPerfil.valueOf(perfilTexto.trim().toUpperCase());
                                    } catch (IllegalArgumentException e) {
                                        // Línea con un perfil desconocido: se ignora
                                        continue;
                                    }

                                    if (usuarioIntroducido.equals(usuarioArchivo)
                                            && passwordIntroducida.equals(passwordArchivo)) {
                                        sesion.setUsuario(usuarioArchivo);
                                        sesion.setNombre(nombre);
                                        sesion.setTipoPerfil(perfil);
                                        sesion.setIniciada(true);

                                        encontrado = true;

                                        System.out.println("Bienvenido :" + nombre + " tienes el rol de: " + perfil);
                                        break;
                                    }
                                }
                            }
                        } catch (IOException e) {
                            System.out.println("Error en la lectura del fichero");
                            break;
                        }
                    }
                    if (encontrado) {
                        mostrarMenuPerfil();
                    } else {
                        System.out.println("Usuario o contraseña incorrectos.");
                    }
                    break;
                }
                case 0: {
                    System.out.println("SALIENDO");
                    break;
                }
                default:
                    System.out.println("OPCION INCORRECTA VUELVA A INTENTARLO");
            }
        } while (opcion != 0);

    }
}