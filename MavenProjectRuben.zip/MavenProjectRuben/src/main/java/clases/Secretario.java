/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */

public class Secretario extends Empleado {

    private int anosExperiencia;

    public Secretario(int anosExperiencia, Long idEmpleado, String nombre, String apellidos,
            String telefono, String email, String nifnie, String direccion) {
        super(idEmpleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.anosExperiencia = anosExperiencia;
    }

    public int getAnosExperiencia() {
        return anosExperiencia;
    }

    public void setAnosExperiencia(int anosExperiencia) {
        this.anosExperiencia = anosExperiencia;
    }
}
