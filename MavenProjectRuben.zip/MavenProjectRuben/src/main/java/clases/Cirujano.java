/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 2DAMV27
 */
public class Cirujano extends Empleado {

    // Un cirujano es experto en una o varias especialidades
    private List<Especialidad> especialidades = new ArrayList<>();

    public Cirujano(Long idEmpleado, String nombre, String apellidos, String telefono,
            String email, String nifnie, String direccion) {
        super(idEmpleado, nombre, apellidos, telefono, email, nifnie, direccion);
    }

    public List<Especialidad> getEspecialidades() {
        return especialidades;
    }

    public void setEspecialidades(List<Especialidad> especialidades) {
        this.especialidades = especialidades;
    }

    public void addEspecialidad(Especialidad especialidad) {
        this.especialidades.add(especialidad);
    }
}

