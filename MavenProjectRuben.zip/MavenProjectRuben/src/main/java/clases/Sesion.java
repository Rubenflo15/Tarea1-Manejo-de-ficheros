/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */

public class Sesion {

    private String usuario;
    private String nombre;
    private TipoPerfil tipoPerfil;
    private boolean iniciada;

    public Sesion(String usuario, String nombre, TipoPerfil tipoPerfil, boolean iniciada) {
        this.usuario = usuario;
        this.nombre = nombre;
        this.tipoPerfil = tipoPerfil;
        this.iniciada = iniciada;
    }

    // Al arrancar el programa se es invitado y no hay sesión iniciada
    public Sesion() {
        this.tipoPerfil = TipoPerfil.INVITADO;
        this.iniciada = false;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoPerfil getTipoPerfil() {
        return tipoPerfil;
    }

    public void setTipoPerfil(TipoPerfil tipoPerfil) {
        this.tipoPerfil = tipoPerfil;
    }

    public boolean isIniciada() {
        return iniciada;
    }

    public void setIniciada(boolean iniciada) {
        this.iniciada = iniciada;
    }
}