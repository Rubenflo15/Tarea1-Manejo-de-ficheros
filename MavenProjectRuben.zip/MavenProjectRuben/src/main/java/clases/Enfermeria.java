/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */

public class Enfermeria extends Empleado {

    private Tipocategoria categoria;

    public Enfermeria(Tipocategoria categoria, Long idEmpleado, String nombre, String apellidos,
            String telefono, String email, String nifnie, String direccion) {
        super(idEmpleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.categoria = categoria;
    }

    public Tipocategoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Tipocategoria categoria) {
        this.categoria = categoria;
    }
}