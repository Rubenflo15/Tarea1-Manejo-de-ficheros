/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Alergia {
    private Long id_alergia;
    private String nombre;
    private Historial historial;

    private Medicamento medicamento;
    
    public Alergia(Long id_alergia, String nombre, Historial historial) {
        this.id_alergia = id_alergia;
        this.nombre = nombre;
        this.historial = historial;
    }

    public Long getId_alergia() {
        return id_alergia;
    }

    public void setId_alergia(Long id_alergia) {
        this.id_alergia = id_alergia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Historial getHistorial() {
        return historial;
    }

    public void setHistorial(Historial historial) {
        this.historial = historial;
    }

    
    
}
