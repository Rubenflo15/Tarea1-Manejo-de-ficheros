/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDate;
import java.util.Set;

/**
 *
 * @author 2DAMV27
 */
public class Paciente {
    private Long id;
    private String nombre;
    private  LocalDate fechanac;
    private String telefono;
    private String email;
    private String direccion;
    private String nif;
    
    private Set<Long> idtratamientos;
    
    //Constructor

    public Paciente(Long id, String nombre, LocalDate fechanac, String telefono, String email, String direccion, String nif) {
        this.id = id;
        this.nombre = nombre;
        this.fechanac = fechanac;
        this.telefono = telefono;
        this.email = email;
        this.direccion = direccion;
        this.nif = nif;
    }
    
    //Getter y Setter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public LocalDate getFechanac() {
        return fechanac;
    }

    public void setFechanac(LocalDate fechanac) {
        this.fechanac = fechanac;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getnif() {
        return nif;
    }

    public void setnif(String Nif) {
        this.nif = Nif;
    }
    
    
    
}
