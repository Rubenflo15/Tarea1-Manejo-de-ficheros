/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Cirujano extends Empleado{
    
    private Long id_cirujano;

    public Cirujano(Long id_cirujano, Long id_empleado, String nombre, String apellidos, String telefono, String email, String nifnie, String direccion) {
        super(id_empleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.id_cirujano = id_cirujano;
    }

    public Long getId_cirujano() {
        return id_cirujano;
    }

    public void setId_cirujano(Long id_cirujano) {
        this.id_cirujano = id_cirujano;
    }
    
    
    
}
