/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author 2DAMV27
 */
public class Cita {
    
    private Long id;
    protected LocalDate fechaHora;

    public Cita(Long id, LocalDate fechaHora) {
        this.id = id;
        this.fechaHora = fechaHora;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDate fechaHora) {
        this.fechaHora = fechaHora;
    }

  
    

    

    
    
    
    
}
