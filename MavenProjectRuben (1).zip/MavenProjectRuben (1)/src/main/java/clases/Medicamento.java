/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Medicamento {
    
    private Long id;
    private String nombre;
    private String activo;
    private int maxDosis;

    public Medicamento(Long id, String nombre, String activo, int maxDosis) { 
        this.id = id;
        this.nombre = nombre;
        this.activo = activo;
        this.maxDosis = maxDosis;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getActivo() {
        return activo;
    }

    public void setActivo(String activo) {
        this.activo = activo;
    }

    public int getMaxDosis() {
        return maxDosis;
    }

    public void setMaxDosis(int maxDosis) {
        this.maxDosis = maxDosis;
    }
    
    
}
