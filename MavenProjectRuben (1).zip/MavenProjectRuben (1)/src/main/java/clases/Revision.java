/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author 2DAMV27
 */
public class Revision extends Cita{
    
    private Long id;
    private String anotaciones;

    public Revision(Long id,String anotaciones,LocalDate fechaHora) {
        super(id, fechaHora);
        this.id = id;
        this.anotaciones = anotaciones;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAnotaciones() {
        return anotaciones;
    }

    public void setAnotaciones(String anotaciones) {
        this.anotaciones = anotaciones;
    }

   
   
 

}
