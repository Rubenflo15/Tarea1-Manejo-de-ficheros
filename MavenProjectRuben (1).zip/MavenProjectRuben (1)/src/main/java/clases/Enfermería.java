/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Enfermería  extends Empleado{
    private Long id_enfermería;
    private Tipocategoria tipocategoria;

    public Enfermería(Long id_enfermería, Tipocategoria tipocategoria, Long id_empleado, String nombre, String apellidos, String telefono, String email, String nifnie, String direccion) {
        super(id_empleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.id_enfermería = id_enfermería;
        this.tipocategoria = tipocategoria;
    }

    public Long getId_enfermería() {
        return id_enfermería;
    }

    public void setId_enfermería(Long id_enfermería) {
        this.id_enfermería = id_enfermería;
    }

    public Tipocategoria getTipocategoria() {
        return tipocategoria;
    }

    public void setTipocategoria(Tipocategoria tipocategoria) {
        this.tipocategoria = tipocategoria;
    }


    
}
