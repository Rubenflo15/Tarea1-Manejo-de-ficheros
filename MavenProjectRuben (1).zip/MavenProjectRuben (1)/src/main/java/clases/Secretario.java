/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Secretario extends Empleado {
    private Long id_secretario;
    private int añosExp;

    public Secretario(Long id_secretario, int añosExp, Long id_empleado, String nombre, String apellidos, String telefono, String email, String nifnie, String direccion) {
        super(id_empleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.id_secretario = id_secretario;
        this.añosExp = añosExp;
    }

    public Long getId_secretario() {
        return id_secretario;
    }

    public void setId_secretario(Long id_secretario) {
        this.id_secretario = id_secretario;
    }

    public int getAñosExp() {
        return añosExp;
    }

    public void setAñosExp(int añosExp) {
        this.añosExp = añosExp;
    }


    
}
