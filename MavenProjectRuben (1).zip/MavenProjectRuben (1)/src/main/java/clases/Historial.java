/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Set;

/**
 *
 * @author 2DAMV27
 */
public class Historial {
    
    private Long id;
    private Long numHistorial;
    private String descripcion;
    private Paciente paciene;
    
    private Set<Alergia> idalergias;

    public Historial(Long id, Long numHistorial, String descripcion, Paciente paciene, Set<Alergia> idalergias) {
        this.id = id;
        this.numHistorial = numHistorial;
        this.descripcion = descripcion;
        this.paciene = paciene;
        this.idalergias = idalergias;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getNumHistorial() {
        return numHistorial;
    }

    public void setNumHistorial(Long numHistorial) {
        this.numHistorial = numHistorial;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Paciente getPaciene() {
        return paciene;
    }

    public void setPaciene(Paciente paciene) {
        this.paciene = paciene;
    }

    public Set<Alergia> getIdalergias() {
        return idalergias;
    }

    public void setIdalergias(Set<Alergia> idalergias) {
        this.idalergias = idalergias;
    }
    
    
}
