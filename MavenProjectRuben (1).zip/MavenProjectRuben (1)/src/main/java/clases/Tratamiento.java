
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDate;

/**
 *
 * @author 2DAMV27
 */
public class Tratamiento {
    
    private Long id; 
    private String nombreDes;
    private LocalDate fechaInc= LocalDate.now();
    private boolean consentimiento= false;
    
       private Long idpaciente;//CARGA LIGERA
    
    private Paciente paciente;//CARGA PESADA
    
    
 public Long getIdpaciente() {
        return idpaciente;
    }

    public void setIdpaciente(Long idpaciente) {
        this.idpaciente = idpaciente;
    }

       public Paciente getPaciente() {
        return paciente;
    }


    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }
    
     
  
    //Constructor

    public Tratamiento(Long id, String nombreDes, LocalDate fechaInc, boolean consentimiento) {
        this.id = id;
        this.nombreDes = nombreDes;
        this.fechaInc = fechaInc;
        this.consentimiento = consentimiento;
    }
    
    
    //Getter y Setter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreDes() {
        return nombreDes;
    }

    public void setNombreDes(String nombreDes) {
        this.nombreDes = nombreDes;
    }

    public LocalDate getFechaInc() {
        return fechaInc;
    }

    public void setFechaInc(LocalDate fechaInc) {
        this.fechaInc = fechaInc;
    }

    public boolean isConsentimiento() {
        return consentimiento;
    }

    public void setConsentimiento(boolean consentimiento) {
        this.consentimiento = consentimiento;
    }
    
    
    
}