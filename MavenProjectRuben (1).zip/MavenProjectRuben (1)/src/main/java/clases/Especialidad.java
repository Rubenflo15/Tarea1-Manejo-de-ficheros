/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class Especialidad extends Cirujano {
    
    private Long id_especialidad;
    private String nombre_especialidad;

    public Especialidad(Long id_especialidad, String nombre_especialidad, Long id_cirujano, Long id_empleado, String nombre, String apellidos, String telefono, String email, String nifnie, String direccion) {
        super(id_cirujano, id_empleado, nombre, apellidos, telefono, email, nifnie, direccion);
        this.id_especialidad = id_especialidad;
        this.nombre_especialidad = nombre_especialidad;
    }

    public Long getId_especialidad() {
        return id_especialidad;
    }

    public void setId_especialidad(Long id_especialidad) {
        this.id_especialidad = id_especialidad;
    }

    public String getNombre_especialidad() {
        return nombre_especialidad;
    }

    public void setNombre_especialidad(String nombre_especialidad) {
        this.nombre_especialidad = nombre_especialidad;
    }
     
    
}
