/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV27
 */
public class HistorialAlergia {
    
    private Long historialAlergia;
    private Long idhistorial;
    private Long idalergia;

    public HistorialAlergia(Long historialAlergia, Long idhistorial, Long idalergia) {
        this.historialAlergia = historialAlergia;
        this.idhistorial = idhistorial;
        this.idalergia = idalergia;
    }
    
    

    public Long getHistorialAlergia() {
        return historialAlergia;
    }

    public void setHistorialAlergia(Long historialAlergia) {
        this.historialAlergia = historialAlergia;
    }

    public Long getIdhistorial() {
        return idhistorial;
    }

    public void setIdhistorial(Long idhistorial) {
        this.idhistorial = idhistorial;
    }

    public Long getIdalergia() {
        return idalergia;
    }

    public void setIdalergia(Long idalergia) {
        this.idalergia = idalergia;
    }
        
    
    
}
