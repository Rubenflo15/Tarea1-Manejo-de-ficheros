/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.mavenprojectruben;

import clases.Sesion;
import clases.TipoPerfil;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.InputStream;
import java.util.Properties;

/**
 *
 * @author Ruben
 */
public class MavenProjectRuben {

    private static String[] login() {
        System.out.println("Nombre de usuario");
        String usuario = sc.nextLine();
        System.out.println("Contraseña");
        String contraseña = sc.nextLine();

        if (usuario.isEmpty() || contraseña.isEmpty()) {
            System.out.println("El campo usuario y contraseña no pueden estar vacios");
            return null;
        }
        return new String[]{usuario, contraseña};
    }

    private static Properties cargarPropiedades() {
        Properties propiedades = new Properties();

        try (InputStream entrada = MavenProjectRuben.class
                .getClassLoader()
                .getResourceAsStream("application.properties")) {

            if (entrada == null) {
                System.out.println("No se encuentra application.properties");
                return null;
            }

            propiedades.load(entrada);

        } catch (IOException e) {
            System.out.println("Error al leer las propiedades");
            return null;
        }

        return propiedades;
    }

 
private static void mostrarMenuPerfil() {
    int opcion;

    do {
        // Mostrar las opciones según el perfil
        System.out.println("--- MENÚ PRINCIPAL ---");

        switch (sesion.getTipoPerfil()) {
            case INVITADO:
                System.out.println("1.- Iniciar sesión");
                System.out.println("0.- Salir");
                break;

            case SECRETARIADO:
                System.out.println("1.- Gestionar empleados");
                System.out.println("2.- Cerrar sesión");
                break;

            case ENFERMERIA:
                System.out.println("1.- Gestionar alergias y medicamentos");
                System.out.println("2.- Cerrar sesión");
                break;

            case ADMINISTRADOR:
                System.out.println("1.- Gestionar empleados");
                System.out.println("2.- Gestionar alergias y medicamentos");
                System.out.println("3.- Cerrar sesión");
                break;
        }

        System.out.println("Elige una opción:");
        
        try {
            opcion = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Debes introducir un número.");
            opcion = -1;
            continue;
        }

        // Ejecutar la opción seleccionada
        switch (sesion.getTipoPerfil()) {

            case INVITADO:
                if (opcion != 0 && opcion != 1) {
                    System.out.println("Opción incorrecta.");
                } else if (opcion == 1) {
                    System.out.println("Vuelve al menú principal para iniciar sesión.");
                    return;
                }
                break;

            case SECRETARIADO:
                switch (opcion) {
                    case 1:
                        System.out.println("Aquí irá la gestión de empleados.");
                        break;
                    case 2:
                        cerrarSesion();
                        break;
                    default:
                        System.out.println("Opción incorrecta.");
                }
                break;

            case ENFERMERIA:
                switch (opcion) {
                    case 1:
                        System.out.println("Aquí irá la gestión de alergias y medicamentos.");
                        break;
                    case 2:
                        cerrarSesion();
                        break;
                    default:
                        System.out.println("Opción incorrecta.");
                }
                break;

            case ADMINISTRADOR:
                switch (opcion) {
                    case 1:
                        System.out.println("Aquí irá la gestión de empleados.");
                        break;
                    case 2:
                        System.out.println("Aquí irá la gestión de alergias y medicamentos.");
                        break;
                    case 3:
                        cerrarSesion();
                        break;
                    default:
                        System.out.println("Opción incorrecta.");
                }
                break;
        }

    } while (sesion.isIniciada() && opcion != 0);
}

private static void cerrarSesion(){
      if (sesion.isIniciada()) {
                        sesion.setUsuario(null);
                        sesion.setNombre(null);
                        sesion.setTipoPerfil(TipoPerfil.INVITADO);
                        sesion.setIniciada(false);
                        System.out.println("Sesion cerrada correctamente");
                        System.out.println("Pasa a usuario invitado");
                    } 
}
    static Scanner sc = new Scanner(System.in);
    //Delcaro el objeto sesion para que guarde los datos 
    static Sesion sesion = new Sesion();

    public static void main(String[] args) {

        Path ruta = Path.of("credenciales.txt");

        int opcion;
        boolean encontrado = false;

        do {
            System.out.println("--- MENÚ PRINCIPAL ---");
            System.out.println("1.-Login");
            System.out.println("2.-Cerrar sesión");
            System.out.println("0.-Salir");
            opcion = Integer.parseInt(sc.nextLine());
            switch (opcion) {
                case 1: {
                    if (sesion.isIniciada()) {
                        System.out.println("Ya hay una sesion iniciada. Cierra sesión antes de volver a entrar");
                        break;
                    }
                    String[] credenciales = login();
                    if (credenciales == null) {
                        break;
                    }
                    String usuarioIntroducido = credenciales[0];
                    String contraseñaIntroducida = credenciales[1];
                    encontrado = false;
                    Properties propiedades = cargarPropiedades();

                    if (propiedades != null) {
                        String usuarioAdmin = propiedades.getProperty("admin.usuario");
                        String passwordAdmin = propiedades.getProperty("admin.password");

                        if (usuarioIntroducido.equals(usuarioAdmin)
                                && contraseñaIntroducida.equals(passwordAdmin)) {

                            sesion.setUsuario(usuarioAdmin);
                            sesion.setNombre("Administrador General");
                            sesion.setTipoPerfil(TipoPerfil.ADMINISTRADOR);
                            sesion.setIniciada(true);

                            encontrado = true;
                            System.out.println("Bienvenido: Administrador General");
                        }
                    }
                    if (!encontrado) {

                        try (BufferedReader br = Files.newBufferedReader(ruta)) {
                            String linea;

                            while ((linea = br.readLine()) != null) {
                                String[] datos = linea.split("\\|", -1);

                                if (datos.length == 4) {
                                    String usuarioArchivo = datos[0];
                                    String contraseñaArchivo = datos[1];
                                    String nombre = datos[2];
                                    String perfilTexto = datos[3];
                                    TipoPerfil perfil = TipoPerfil.valueOf(perfilTexto.trim().toUpperCase());

                                    if (usuarioIntroducido.equals(usuarioArchivo) && contraseñaIntroducida.equals(contraseñaArchivo)) {
                                        sesion.setUsuario(usuarioArchivo);
                                        sesion.setNombre(nombre);
                                        sesion.setTipoPerfil(perfil);
                                        sesion.setIniciada(true);

                                        encontrado = true;

                                        System.out.println("Bienvenido :" + nombre + " tienes el rol de: " + perfil);
                                        break;
                                    }

                                }
                            }
                        } catch (IOException e) {
                        System.out.println("Error en la lectura del fichero");
                                    break;
                    }
                        }
                        if (encontrado) {
                         mostrarMenuPerfil();
                        } else {
                            System.out.println("Usuario o contraseña incorrectos.");
                        }
                        break;
                    }         
            case 2: {
                    if (sesion.isIniciada()) {
                        cerrarSesion();
                    } else {
                        System.out.println("No hay ninguna sesion iniciada");
                    }
                    break;
                }
                case 0: {
                    System.out.println("SALIENDO");
                    break;
                }
                default:
                    System.out.println("OPCION INCORRECTA VUELVA A INTENTARLO");

            }
        } while (opcion != 0);

        }
    }
